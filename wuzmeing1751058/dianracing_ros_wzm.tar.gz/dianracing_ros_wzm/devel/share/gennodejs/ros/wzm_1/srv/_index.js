
"use strict";

let multi = require('./multi.js')

module.exports = {
  multi: multi,
};
